# CLASS — Arquitectura SaaS Multi-tenant

Base de plataforma Next.js + Supabase para operaciones reales de negocios físicos.

## Principios
- Multi-tenant estricto por `auth.uid()` + `store_id` activo.
- Persistencia 100% en Supabase (sin datos mock).
- RLS en todas las tablas operativas.
- Automatización de contabilidad desde movimientos de stock.

## Setup
1. Configurar `.env.local`.
2. Ejecutar migraciones SQL dentro de Supabase.
3. Ejecutar `npm install` y `npm run dev`.

## Dominio
Ver `supabase/migrations/0001_class_schema.sql`.
